import os

# Define a skeleton for RomGenerator class
class RomGenerator:
    def __init__(self, rom_path):
        self.rom_path = rom_path

    def create_rom(self):
        # Your logic here
        return Rom()

class Rom:
    def add_object(self, obj_name, position):
        # Your logic here
        pass

    def add_text(self, text, position):
        # Your logic here
        pass

    def scale_object(self, obj_name, scale):
        # Your logic here
        pass

    def save(self, save_path):
        # Your logic here
        pass

# Define the path to the generatez64.py file
generatez64_path = os.path.join(os.path.dirname(os.path.realpath(__file__)), 'generatez64.py')

# Initialize RomGenerator
rom_generator = RomGenerator('Super Mario 64 (U) [!].z64')

# Create ROM
rom = rom_generator.create_rom()

# Add 1up mushroom
rom.add_object('1up_mushroom', position=(0, 0))

# Add 'Debug Super Mario' text
rom.add_text('Debug Super Mario', position=(0, 120))

# Scale 1up mushroom
rom.scale_object('1up_mushroom', scale=(2, 2))

# Add Japanese words test
rom.add_text('テスト', position=(0, 200))

# Save ROM
rom.save('debugultra4k.z64')
